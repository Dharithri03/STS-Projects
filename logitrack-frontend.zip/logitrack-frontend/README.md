# LogiTrack Cargo Management System

## How to Run

1. Open terminal
2. Go to project folder:
   ```
   cd logitrack-frontend
   ```
3. Install dependencies:
   ```
   npm install
   ```
4. Start the app:
   ```
   npm start
   ```
5. Open browser: http://localhost:3000

## Member 9 Files
- src/pages/ViewCargoStatus.jsx   — Customer cargo tracking
- src/components/NotificationBell.jsx  — Bell icon with unread badge
- src/components/NotificationInbox.jsx — Notification list with mark-as-read

## Test Tracking IDs
- C001 (In Transit)
- C002 (Delivered)
- C003 (Pending)
