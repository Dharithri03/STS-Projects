// helpers.js
// Utility / helper functions used across the project

// Format a date to readable Indian format
export const formatDate = (date) => {
  return new Date(date).toLocaleDateString("en-IN");
};

// Capitalize first letter of a string
export const capitalize = (str) => {
  if (!str) return "";
  return str.charAt(0).toUpperCase() + str.slice(1);
};
