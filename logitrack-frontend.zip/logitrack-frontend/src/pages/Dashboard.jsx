import React from "react";

function Dashboard() {
  return (
    <div className="container">
      <h2>📊 Dashboard</h2>

      <div style={styles.cardRow}>
        <div style={{ ...styles.card, borderLeft: "4px solid #3498db" }}>
          <h3 style={styles.cardNumber}>25</h3>
          <p style={styles.cardLabel}>Total Cargo</p>
        </div>

        <div style={{ ...styles.card, borderLeft: "4px solid #27ae60" }}>
          <h3 style={styles.cardNumber}>10</h3>
          <p style={styles.cardLabel}>Total Drivers</p>
        </div>

        <div style={{ ...styles.card, borderLeft: "4px solid #e67e22" }}>
          <h3 style={styles.cardNumber}>6</h3>
          <p style={styles.cardLabel}>Active Deliveries</p>
        </div>
      </div>

      <div style={styles.links}>
        <a href="/addcargo" style={styles.link}>➕ Add Cargo</a>
        <a href="/cargolist" style={styles.link}>📦 View Cargo List</a>
        <a href="/assign-driver" style={styles.link}>🚗 Assign Driver</a>
        <a href="/track-cargo" style={styles.link}>📍 Track Cargo</a>
      </div>
    </div>
  );
}

const styles = {
  cardRow: {
    display: "flex",
    gap: "20px",
    marginBottom: "30px",
    flexWrap: "wrap",
  },
  card: {
    backgroundColor: "white",
    padding: "20px 30px",
    borderRadius: "8px",
    boxShadow: "0 2px 6px rgba(0,0,0,0.1)",
    minWidth: "150px",
  },
  cardNumber: {
    margin: 0,
    fontSize: "28px",
    color: "#2c3e50",
  },
  cardLabel: {
    margin: "5px 0 0",
    color: "#777",
    fontSize: "14px",
  },
  links: {
    display: "flex",
    gap: "12px",
    flexWrap: "wrap",
  },
  link: {
    padding: "10px 18px",
    backgroundColor: "#2980b9",
    color: "white",
    borderRadius: "6px",
    textDecoration: "none",
    fontSize: "14px",
  },
};

export default Dashboard;
