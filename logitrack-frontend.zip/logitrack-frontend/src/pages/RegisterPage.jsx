import React, { useState } from "react";

function RegisterPage() {
  const [username, setUsername] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [role, setRole] = useState("");
  const [message, setMessage] = useState("");

  const handleRegister = () => {
    if (!username || !email || !password || !role) {
      setMessage("Please fill all fields");
      return;
    }
    setMessage("Registered successfully! Please login.");
  };

  return (
    <div className="container">
      <h2>📋 Register</h2>

      <input
        placeholder="Username"
        value={username}
        onChange={(e) => setUsername(e.target.value)}
        style={styles.input}
      />
      <br />

      <input
        placeholder="Email"
        value={email}
        onChange={(e) => setEmail(e.target.value)}
        style={styles.input}
      />
      <br />

      <input
        type="password"
        placeholder="Password"
        value={password}
        onChange={(e) => setPassword(e.target.value)}
        style={styles.input}
      />
      <br />

      <select
        value={role}
        onChange={(e) => setRole(e.target.value)}
        style={styles.input}
      >
        <option value="">Select Role</option>
        <option value="Admin">Admin</option>
        <option value="Business">Business</option>
        <option value="Driver">Driver</option>
        <option value="Customer">Customer</option>
      </select>
      <br />

      <button onClick={handleRegister} style={styles.button}>
        Register
      </button>

      {message && <p style={styles.msg}>{message}</p>}
    </div>
  );
}

const styles = {
  input: {
    width: "100%",
    padding: "10px",
    marginBottom: "12px",
    fontSize: "15px",
    border: "1px solid #ccc",
    borderRadius: "6px",
    boxSizing: "border-box",
  },
  button: {
    padding: "10px 25px",
    backgroundColor: "#27ae60",
    color: "white",
    border: "none",
    borderRadius: "6px",
    cursor: "pointer",
    fontSize: "15px",
  },
  msg: {
    color: "green",
    marginTop: "10px",
  },
};

export default RegisterPage;
