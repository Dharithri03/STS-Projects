import React, { useState } from "react";

function AddCargo() {
  const [cargo, setCargo] = useState("");
  const [origin, setOrigin] = useState("");
  const [destination, setDestination] = useState("");
  const [message, setMessage] = useState("");

  const handleAdd = () => {
    if (!cargo || !origin || !destination) {
      setMessage("Please fill all fields");
      return;
    }
    setMessage("Cargo added successfully!");
    setCargo("");
    setOrigin("");
    setDestination("");
  };

  return (
    <div className="container">
      <h2>➕ Add Cargo</h2>

      <input
        placeholder="Cargo Name"
        value={cargo}
        onChange={(e) => setCargo(e.target.value)}
        style={styles.input}
      />
      <br />

      <input
        placeholder="Origin City"
        value={origin}
        onChange={(e) => setOrigin(e.target.value)}
        style={styles.input}
      />
      <br />

      <input
        placeholder="Destination City"
        value={destination}
        onChange={(e) => setDestination(e.target.value)}
        style={styles.input}
      />
      <br />

      <button onClick={handleAdd} style={styles.button}>
        Add Cargo
      </button>

      {message && <p style={styles.msg}>{message}</p>}
    </div>
  );
}

const styles = {
  input: {
    width: "100%",
    padding: "10px",
    marginBottom: "12px",
    fontSize: "15px",
    border: "1px solid #ccc",
    borderRadius: "6px",
    boxSizing: "border-box",
  },
  button: {
    padding: "10px 25px",
    backgroundColor: "#8e44ad",
    color: "white",
    border: "none",
    borderRadius: "6px",
    cursor: "pointer",
    fontSize: "15px",
  },
  msg: { color: "green", marginTop: "10px" },
};

export default AddCargo;
