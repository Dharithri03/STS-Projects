import React, { useState } from "react";

function AssignDriver() {
  const [selectedCargo, setSelectedCargo] = useState("");
  const [selectedDriver, setSelectedDriver] = useState("");
  const [message, setMessage] = useState("");

  const handleAssign = () => {
    if (!selectedCargo || !selectedDriver) {
      setMessage("Please select both cargo and driver");
      return;
    }
    setMessage(`Driver ${selectedDriver} assigned to ${selectedCargo} successfully!`);
  };

  return (
    <div className="container">
      <h2>🚗 Assign Driver</h2>

      <label style={styles.label}>Select Cargo</label>
      <select
        value={selectedCargo}
        onChange={(e) => setSelectedCargo(e.target.value)}
        style={styles.input}
      >
        <option value="">-- Select Cargo --</option>
        <option value="C001 - Electronic Goods">C001 - Electronic Goods</option>
        <option value="C002 - Furniture">C002 - Furniture</option>
        <option value="C003 - Clothes">C003 - Clothes</option>
      </select>
      <br />

      <label style={styles.label}>Select Driver</label>
      <select
        value={selectedDriver}
        onChange={(e) => setSelectedDriver(e.target.value)}
        style={styles.input}
      >
        <option value="">-- Select Driver --</option>
        <option value="Suresh Babu">Suresh Babu</option>
        <option value="Mahesh Rao">Mahesh Rao</option>
        <option value="Ravi Kumar">Ravi Kumar</option>
      </select>
      <br />

      <button onClick={handleAssign} style={styles.button}>
        Assign Driver
      </button>

      {message && <p style={styles.msg}>{message}</p>}
    </div>
  );
}

const styles = {
  label: { display: "block", marginBottom: "5px", fontWeight: "bold", color: "#555" },
  input: {
    width: "100%",
    padding: "10px",
    marginBottom: "15px",
    fontSize: "15px",
    border: "1px solid #ccc",
    borderRadius: "6px",
    boxSizing: "border-box",
  },
  button: {
    padding: "10px 25px",
    backgroundColor: "#e67e22",
    color: "white",
    border: "none",
    borderRadius: "6px",
    cursor: "pointer",
    fontSize: "15px",
  },
  msg: { color: "green", marginTop: "10px" },
};

export default AssignDriver;
