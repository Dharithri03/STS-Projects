import React from "react";

function TrackCargo() {
  return (
    <div className="container">
      <h2>📍 Track Cargo</h2>

      <div style={styles.card}>
        <p><strong>Cargo ID:</strong> C001</p>
        <p><strong>Item:</strong> Electronic Goods</p>
        <p><strong>Current Location:</strong> Vijayawada</p>
        <p><strong>ETA:</strong> 3 Hours</p>
        <p>
          <strong>Status:</strong>{" "}
          <span style={{ color: "#e67e22", fontWeight: "bold" }}>In Transit</span>
        </p>
      </div>
    </div>
  );
}

const styles = {
  card: {
    backgroundColor: "#eaf4fb",
    border: "1px solid #aed6f1",
    borderRadius: "8px",
    padding: "20px",
    maxWidth: "400px",
    fontSize: "15px",
    lineHeight: "1.8",
  },
};

export default TrackCargo;
