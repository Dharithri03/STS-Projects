import React from "react";

function DriverDashboard() {
  return (
    <div className="container">
      <h2>🚚 Driver Dashboard</h2>
      <p>Assigned Cargo: C001 - Electronic Goods</p>
      <p>Route: Hyderabad → Chennai</p>
      <p>Status: In Transit</p>
    </div>
  );
}

export default DriverDashboard;
