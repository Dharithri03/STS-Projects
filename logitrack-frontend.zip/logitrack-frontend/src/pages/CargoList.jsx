import React from "react";

function CargoList() {
  const cargos = [
    { id: "C001", name: "Electronic Goods", from: "Hyderabad", to: "Chennai", status: "In Transit" },
    { id: "C002", name: "Furniture",        from: "Bangalore", to: "Chennai", status: "Delivered"  },
    { id: "C003", name: "Clothes",          from: "Mumbai",    to: "Delhi",   status: "Pending"    },
  ];

  const statusColor = (s) => {
    if (s === "Delivered")  return "#27ae60";
    if (s === "In Transit") return "#e67e22";
    return "#c0392b";
  };

  return (
    <div className="container">
      <h2>📦 Cargo List</h2>

      <table style={styles.table}>
        <thead>
          <tr style={styles.thead}>
            <th style={styles.th}>Cargo ID</th>
            <th style={styles.th}>Item Name</th>
            <th style={styles.th}>From</th>
            <th style={styles.th}>To</th>
            <th style={styles.th}>Status</th>
          </tr>
        </thead>
        <tbody>
          {cargos.map((c) => (
            <tr key={c.id} style={styles.tr}>
              <td style={styles.td}>{c.id}</td>
              <td style={styles.td}>{c.name}</td>
              <td style={styles.td}>{c.from}</td>
              <td style={styles.td}>{c.to}</td>
              <td style={{ ...styles.td, color: statusColor(c.status), fontWeight: "bold" }}>
                {c.status}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

const styles = {
  table: { width: "100%", borderCollapse: "collapse", backgroundColor: "white", borderRadius: "8px", overflow: "hidden", boxShadow: "0 2px 6px rgba(0,0,0,0.1)" },
  thead: { backgroundColor: "#2c3e50" },
  th: { padding: "12px 15px", color: "white", textAlign: "left", fontSize: "14px" },
  tr: { borderBottom: "1px solid #eee" },
  td: { padding: "11px 15px", fontSize: "14px", color: "#2c3e50" },
};

export default CargoList;
