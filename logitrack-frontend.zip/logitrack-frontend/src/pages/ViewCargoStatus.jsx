import React, { useState } from "react";

function ViewCargoStatus() {
  const [trackingId, setTrackingId] = useState("");
  const [cargoInfo, setCargoInfo] = useState(null);
  const [error, setError] = useState("");

  // Sample cargo data — replace with API call later
  const sampleData = {
    C001: {
      id: "C001",
      itemName: "Electronic Goods",
      senderName: "Ramesh Kumar",
      receiverName: "Priya Sharma",
      driverName: "Suresh Babu",
      status: "In Transit",
      currentLocation: "Vijayawada",
      eta: "3 Hours",
      origin: "Hyderabad",
      destination: "Chennai",
    },
    C002: {
      id: "C002",
      itemName: "Furniture",
      senderName: "Anita Reddy",
      receiverName: "Vikram Singh",
      driverName: "Mahesh Rao",
      status: "Delivered",
      currentLocation: "Chennai",
      eta: "Delivered",
      origin: "Bangalore",
      destination: "Chennai",
    },
    C003: {
      id: "C003",
      itemName: "Clothes",
      senderName: "Kavitha Nair",
      receiverName: "Arjun Verma",
      driverName: "Ravi Kumar",
      status: "Pending",
      currentLocation: "Mumbai",
      eta: "Not Started",
      origin: "Mumbai",
      destination: "Delhi",
    },
  };

  const handleSearch = () => {
    if (trackingId.trim() === "") {
      setError("Please enter a Tracking ID");
      setCargoInfo(null);
      return;
    }

    const found = sampleData[trackingId.toUpperCase()];

    if (found) {
      setCargoInfo(found);
      setError("");
    } else {
      setError("No cargo found with this Tracking ID. Try C001, C002 or C003.");
      setCargoInfo(null);
    }
  };

  const getStatusColor = (status) => {
    if (status === "Delivered")  return "#27ae60";
    if (status === "In Transit") return "#e67e22";
    if (status === "Pending")    return "#c0392b";
    return "#2c3e50";
  };

  return (
    <div className="container">
      <h2>📦 Track Your Cargo</h2>

      {/* Search Box */}
      <div style={styles.searchBox}>
        <input
          type="text"
          placeholder="Enter Tracking ID  (e.g. C001)"
          value={trackingId}
          onChange={(e) => setTrackingId(e.target.value)}
          style={styles.input}
        />
        <button onClick={handleSearch} style={styles.button}>
          Search
        </button>
      </div>

      {/* Error Message */}
      {error && <p style={styles.error}>{error}</p>}

      {/* Cargo Details Card */}
      {cargoInfo && (
        <div style={styles.card}>
          <h3 style={styles.cardTitle}>Cargo Details</h3>

          <div style={styles.row}>
            <span style={styles.label}>Cargo ID :</span>
            <span>{cargoInfo.id}</span>
          </div>
          <div style={styles.row}>
            <span style={styles.label}>Item :</span>
            <span>{cargoInfo.itemName}</span>
          </div>
          <div style={styles.row}>
            <span style={styles.label}>Sender :</span>
            <span>{cargoInfo.senderName}</span>
          </div>
          <div style={styles.row}>
            <span style={styles.label}>Receiver :</span>
            <span>{cargoInfo.receiverName}</span>
          </div>
          <div style={styles.row}>
            <span style={styles.label}>Driver :</span>
            <span>{cargoInfo.driverName}</span>
          </div>
          <div style={styles.row}>
            <span style={styles.label}>From :</span>
            <span>{cargoInfo.origin}</span>
          </div>
          <div style={styles.row}>
            <span style={styles.label}>To :</span>
            <span>{cargoInfo.destination}</span>
          </div>

          <hr style={{ margin: "15px 0", borderColor: "#ddd" }} />

          {/* Location & ETA Card */}
          <div style={styles.locationCard}>
            <h4 style={{ margin: "0 0 12px", color: "#1a252f" }}>📍 Live Location & ETA</h4>

            <p style={styles.locRow}>
              <strong>Current Location :</strong> {cargoInfo.currentLocation}
            </p>
            <p style={styles.locRow}>
              <strong>ETA :</strong> {cargoInfo.eta}
            </p>
            <p style={styles.locRow}>
              <strong>Status :</strong>{" "}
              <span style={{ color: getStatusColor(cargoInfo.status), fontWeight: "bold" }}>
                {cargoInfo.status}
              </span>
            </p>
          </div>
        </div>
      )}
    </div>
  );
}

const styles = {
  searchBox: {
    display: "flex",
    gap: "10px",
    marginBottom: "15px",
  },
  input: {
    flex: 1,
    padding: "10px",
    fontSize: "15px",
    border: "1px solid #ccc",
    borderRadius: "6px",
  },
  button: {
    padding: "10px 22px",
    backgroundColor: "#2980b9",
    color: "white",
    border: "none",
    borderRadius: "6px",
    cursor: "pointer",
    fontSize: "15px",
  },
  error: {
    color: "red",
    marginBottom: "10px",
    fontSize: "14px",
  },
  card: {
    backgroundColor: "white",
    border: "1px solid #ddd",
    borderRadius: "8px",
    padding: "22px",
    boxShadow: "0 2px 6px rgba(0,0,0,0.08)",
  },
  cardTitle: {
    margin: "0 0 15px",
    color: "#2c3e50",
  },
  row: {
    display: "flex",
    gap: "10px",
    marginBottom: "9px",
    fontSize: "15px",
  },
  label: {
    fontWeight: "bold",
    minWidth: "120px",
    color: "#555",
  },
  locationCard: {
    backgroundColor: "#eaf4fb",
    border: "1px solid #aed6f1",
    borderRadius: "8px",
    padding: "16px",
  },
  locRow: {
    margin: "0 0 8px",
    fontSize: "14px",
  },
};

export default ViewCargoStatus;
