import React, { useState } from "react";
import AuthService from "../services/AuthService";

function LoginPage() {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [message, setMessage] = useState("");

  const handleLogin = () => {
    if (username === "" || password === "") {
      setMessage("Please enter username and password");
      return;
    }
    AuthService.login(username, password);
    setMessage("Login successful! Redirecting...");
  };

  return (
    <div className="container">
      <h2>🔐 Login</h2>

      <input
        type="text"
        placeholder="Username"
        value={username}
        onChange={(e) => setUsername(e.target.value)}
        style={styles.input}
      />
      <br />

      <input
        type="password"
        placeholder="Password"
        value={password}
        onChange={(e) => setPassword(e.target.value)}
        style={styles.input}
      />
      <br />

      <button onClick={handleLogin} style={styles.button}>
        Login
      </button>

      {message && <p style={styles.msg}>{message}</p>}

      <p style={{ marginTop: "15px", fontSize: "14px" }}>
        Don't have an account?{" "}
        <a href="/register" style={{ color: "#2980b9" }}>
          Register here
        </a>
      </p>
    </div>
  );
}

const styles = {
  input: {
    width: "100%",
    padding: "10px",
    marginBottom: "12px",
    fontSize: "15px",
    border: "1px solid #ccc",
    borderRadius: "6px",
    boxSizing: "border-box",
  },
  button: {
    padding: "10px 25px",
    backgroundColor: "#2980b9",
    color: "white",
    border: "none",
    borderRadius: "6px",
    cursor: "pointer",
    fontSize: "15px",
  },
  msg: {
    color: "green",
    marginTop: "10px",
  },
};

export default LoginPage;
