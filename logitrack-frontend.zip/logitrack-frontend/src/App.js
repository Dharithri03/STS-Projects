import React from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";

import Navbar from "./components/Navbar";
import Footer from "./components/Footer";

import LoginPage from "./pages/LoginPage";
import RegisterPage from "./pages/RegisterPage";
import Dashboard from "./pages/Dashboard";
import AddCargo from "./pages/AddCargo";
import CargoList from "./pages/CargoList";
import AssignDriver from "./pages/AssignDriver";
import TrackCargo from "./pages/TrackCargo";
import DriverDashboard from "./pages/DriverDashboard";

function App() {
  return (
    <Router>
      <Navbar />

      <Routes>
        <Route path="/" element={<LoginPage />} />
        <Route path="/register" element={<RegisterPage />} />
        <Route path="/dashboard" element={<Dashboard />} />
        <Route path="/addcargo" element={<AddCargo />} />
        <Route path="/cargolist" element={<CargoList />} />
        <Route path="/assign-driver" element={<AssignDriver />} />
        <Route path="/track-cargo" element={<TrackCargo />} />
        <Route path="/driver-dashboard" element={<DriverDashboard />} />
      </Routes>

      <Footer />
    </Router>
  );
}

export default App;
