import React from "react";

function Footer() {
  return (
    <footer>
      <p>© 2026 LogiTrack Cargo Management System. All rights reserved.</p>
    </footer>
  );
}

export default Footer;
