import React from "react";
import { Link } from "react-router-dom";
import NotificationBell from "./NotificationBell";

function Navbar() {
  return (
    <nav>
      <h3>🚚 LogiTrack</h3>

      <Link to="/">Login</Link> |&nbsp;
      <Link to="/dashboard">Dashboard</Link> |&nbsp;
      <Link to="/addcargo">Add Cargo</Link> |&nbsp;
      <Link to="/cargolist">Cargo List</Link> |&nbsp;
      <Link to="/track-cargo">Track Cargo</Link>

      <div style={{ marginLeft: "auto" }}>
        <NotificationBell />
      </div>
    </nav>
  );
}

export default Navbar;
