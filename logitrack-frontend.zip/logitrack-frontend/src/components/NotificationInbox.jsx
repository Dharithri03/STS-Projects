import React from "react";

function NotificationInbox({ notifications, onMarkAllRead, onMarkOneRead, onClose }) {
  return (
    <div style={styles.inbox}>

      {/* Header */}
      <div style={styles.header}>
        <h4 style={styles.title}>🔔 Notifications</h4>
        <button onClick={onClose} style={styles.closeBtn}>✕</button>
      </div>

      {/* Show "Mark all as read" only if some are unread */}
      {notifications.some((n) => !n.isRead) && (
        <div style={styles.markAllRow}>
          <button onClick={onMarkAllRead} style={styles.markAllBtn}>
            Mark all as read
          </button>
        </div>
      )}

      {/* Notification List */}
      <div style={styles.list}>
        {notifications.length === 0 ? (
          <p style={styles.empty}>No notifications yet</p>
        ) : (
          notifications.map((notif) => (
            <div
              key={notif.id}
              style={{
                ...styles.item,
                backgroundColor: notif.isRead ? "#ffffff" : "#eaf4fb",
              }}
            >
              <div style={styles.itemContent}>
                <p style={styles.message}>{notif.message}</p>
                <span style={styles.time}>{notif.time}</span>
              </div>

              {/* Show button only if not yet read */}
              {!notif.isRead ? (
                <button
                  onClick={() => onMarkOneRead(notif.id)}
                  style={styles.readBtn}
                >
                  Mark read
                </button>
              ) : (
                <span style={styles.readTag}>✔ Read</span>
              )}
            </div>
          ))
        )}
      </div>
    </div>
  );
}

const styles = {
  inbox: {
    position: "absolute",
    top: "35px",
    right: "0px",
    width: "320px",
    backgroundColor: "white",
    border: "1px solid #ddd",
    borderRadius: "8px",
    boxShadow: "0 4px 14px rgba(0,0,0,0.15)",
    zIndex: 999,
    fontFamily: "Arial, sans-serif",
  },
  header: {
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
    padding: "12px 15px",
    borderBottom: "1px solid #eee",
  },
  title: {
    margin: 0,
    fontSize: "15px",
    color: "#2c3e50",
  },
  closeBtn: {
    background: "none",
    border: "none",
    fontSize: "16px",
    cursor: "pointer",
    color: "#888",
  },
  markAllRow: {
    padding: "8px 15px",
    borderBottom: "1px solid #eee",
  },
  markAllBtn: {
    background: "none",
    border: "none",
    color: "#2980b9",
    cursor: "pointer",
    fontSize: "13px",
    padding: 0,
  },
  list: {
    maxHeight: "280px",
    overflowY: "auto",
  },
  item: {
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
    padding: "12px 15px",
    borderBottom: "1px solid #f0f0f0",
  },
  itemContent: {
    flex: 1,
  },
  message: {
    margin: "0 0 4px",
    fontSize: "13px",
    color: "#2c3e50",
  },
  time: {
    fontSize: "11px",
    color: "#999",
  },
  readBtn: {
    background: "none",
    border: "1px solid #2980b9",
    color: "#2980b9",
    borderRadius: "4px",
    cursor: "pointer",
    fontSize: "11px",
    padding: "3px 7px",
    marginLeft: "8px",
    whiteSpace: "nowrap",
  },
  readTag: {
    fontSize: "11px",
    color: "#27ae60",
    marginLeft: "8px",
    whiteSpace: "nowrap",
  },
  empty: {
    textAlign: "center",
    color: "#999",
    padding: "20px",
    fontSize: "13px",
  },
};

export default NotificationInbox;
