import React, { useState } from "react";
import NotificationInbox from "./NotificationInbox";

function NotificationBell() {
  const [showInbox, setShowInbox] = useState(false);

  // Sample notifications — replace with API call later
  const [notifications, setNotifications] = useState([
    {
      id: 1,
      message: "Your cargo C001 is now In Transit",
      time: "10:30 AM",
      isRead: false,
    },
    {
      id: 2,
      message: "Driver Suresh Babu has been assigned to your cargo",
      time: "09:15 AM",
      isRead: false,
    },
    {
      id: 3,
      message: "Cargo C002 has been delivered successfully",
      time: "Yesterday",
      isRead: true,
    },
  ]);

  // Count how many notifications are unread
  const unreadCount = notifications.filter((n) => !n.isRead).length;

  // Mark all notifications as read
  const markAllRead = () => {
    const updated = notifications.map((n) => ({ ...n, isRead: true }));
    setNotifications(updated);
  };

  // Mark a single notification as read by its id
  const markOneRead = (id) => {
    const updated = notifications.map((n) =>
      n.id === id ? { ...n, isRead: true } : n
    );
    setNotifications(updated);
  };

  return (
    <div style={styles.wrapper}>

      {/* Bell Icon */}
      <div
        onClick={() => setShowInbox(!showInbox)}
        style={styles.bellContainer}
        title="Notifications"
      >
        <span style={styles.bellIcon}>🔔</span>

        {/* Red badge — only shows if unread notifications exist */}
        {unreadCount > 0 && (
          <span style={styles.badge}>{unreadCount}</span>
        )}
      </div>

      {/* Inbox Dropdown — shows when bell is clicked */}
      {showInbox && (
        <NotificationInbox
          notifications={notifications}
          onMarkAllRead={markAllRead}
          onMarkOneRead={markOneRead}
          onClose={() => setShowInbox(false)}
        />
      )}
    </div>
  );
}

const styles = {
  wrapper: {
    position: "relative",
    display: "inline-block",
  },
  bellContainer: {
    cursor: "pointer",
    position: "relative",
    display: "inline-block",
    padding: "5px",
  },
  bellIcon: {
    fontSize: "22px",
  },
  badge: {
    position: "absolute",
    top: "0px",
    right: "0px",
    backgroundColor: "red",
    color: "white",
    borderRadius: "50%",
    fontSize: "11px",
    width: "17px",
    height: "17px",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    fontWeight: "bold",
  },
};

export default NotificationBell;
