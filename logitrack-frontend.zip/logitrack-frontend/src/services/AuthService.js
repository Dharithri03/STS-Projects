// AuthService.js
// Handles Login, Registration and JWT Token storage

const AuthService = {

  // Login API call
  login: (username, password) => {
    console.log("Login called with:", username, password);
    // TODO: replace with real API call
    // axios.post("/api/auth/login", { username, password })
    //   .then(res => localStorage.setItem("token", res.data.token))
  },

  // Register API call
  register: (username, email, password, role) => {
    console.log("Register called with:", username, email, role);
    // TODO: replace with real API call
    // axios.post("/api/auth/register", { username, email, password, role })
  },

  // Save JWT token to localStorage
  saveToken: (token) => {
    localStorage.setItem("jwtToken", token);
  },

  // Get saved JWT token
  getToken: () => {
    return localStorage.getItem("jwtToken");
  },

  // Logout — remove token
  logout: () => {
    localStorage.removeItem("jwtToken");
    console.log("User logged out");
  },

};

export default AuthService;
